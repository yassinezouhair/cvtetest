package org.sid;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CvthequeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CvthequeApplication.class, args);
	}

}
